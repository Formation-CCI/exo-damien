<?php

	//	Inclusion du HTML
	include 'index.phtml';